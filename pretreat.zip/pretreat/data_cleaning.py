import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns
sns.set(color_codes=True)

# train_df=pd.read_csv('../input/train.csv')
# train_df=train_df.drop(['ps_reg_03','ps_car_05_cat','ps_car_03_cat'],axis=1)
# train_df.to_csv('../input/train_df.csv')
#

res=pd.read_csv('../result/StratifiedShuffleSplit.csv')
print res.head()