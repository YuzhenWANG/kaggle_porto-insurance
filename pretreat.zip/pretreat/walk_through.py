import numpy as np
import pandas as pd
from matplotlib import pyplot as plt
import seaborn as sns
sns.set(color_codes=True)
from sklearn.ensemble import RandomForestClassifier
import plotly.offline as py
py.init_notebook_mode(connected=True)
import plotly.graph_objs as go
import plotly.tools as tls

train_df=pd.read_csv('../input/train.csv')
print train_df.head()
print train_df.info()

# test_df=pd.read_csv('../input/test.csv')

train_copy = train_df
train_copy = train_copy.replace(-1, np.NaN)
missing_df=train_copy.isnull().sum(axis=0).reset_index()
missing_df.columns=['column_name','missing_count']
missing_df=missing_df.sort_values(by='missing_count')
print missing_df

ratio=train_copy['target'].value_counts().values*1.0/train_copy.shape[0]
print "fill ratio is : ",ratio

rf = RandomForestClassifier(n_estimators=150, max_depth=8, min_samples_leaf=4, max_features=0.2, n_jobs=-1, random_state=0)
rf.fit(train_df.drop(['id', 'target'],axis=1), train_df.target)
features = train_df.drop(['id', 'target'],axis=1).columns.values
print("----- Training Done -----")
y = rf.feature_importances_
x = features
sns.barplot(x,y)


plt.show()